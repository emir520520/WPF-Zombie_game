﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Midterm_zombie
{
    class Zombie
    {
        private string _name;
        private int _geoX;
        private int _geoY;
        public string name
        {
            get { return _name; }
            set { _name = value; }
        }
        public int geoX
        {
            get { return _geoX; }
            set { _geoX = value; }
        }
        public int geoY
        {
            get { return _geoY; }
            set { _geoY = value; }
        }
    }
}
