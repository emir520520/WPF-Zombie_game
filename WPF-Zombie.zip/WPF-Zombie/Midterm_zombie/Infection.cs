﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Midterm_zombie
{
    class Infection
    {
        private int infector_number;
        private string infected_name;
        private int infected_index;
        private int infexted_x;
        private int infected_y;
        private int iteration;

        public int infectorNumber
        {
            get { return infector_number; }
            set { infector_number = value; }
        }
        public string infectedName
        {
            get { return infected_name; }
            set { infected_name = value; }
        }
        public int infectedIndex
        {
            get { return infected_index; }
            set { infected_index = value; }
        }
        public int infectedX    //original row number of human instance
        {
            get { return infexted_x; }
            set { infexted_x = value; }
        }
        public int infectedY    //original col number of human instance
        {
            get { return infected_y; }
            set { infected_y = value; }
        }
        public int ite
        {
            get { return iteration; }
            set { iteration = value; }
        }
    }
}
